let x = A.x
