print_string "foo"
