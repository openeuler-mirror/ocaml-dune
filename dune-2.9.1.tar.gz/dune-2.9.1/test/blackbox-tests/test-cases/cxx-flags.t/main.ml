let () = Printf.printf "%d" (Quad.quad ())
