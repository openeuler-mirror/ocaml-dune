external baz : unit -> int = "baz"
let quad x = baz x
