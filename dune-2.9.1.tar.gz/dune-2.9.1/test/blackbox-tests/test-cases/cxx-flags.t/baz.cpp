#include <caml/mlvalues.h>
extern "C" value baz(value unit) { return Val_int(2046); }
