let a = 3
let _ = a
