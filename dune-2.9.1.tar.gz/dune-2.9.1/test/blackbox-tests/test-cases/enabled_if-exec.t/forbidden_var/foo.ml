print_string "bar"
