(* directly usable but will cause linking error *)
let run = Foo.run
