prerr_endline ("Formatting " ^ Sys.argv.(1))
