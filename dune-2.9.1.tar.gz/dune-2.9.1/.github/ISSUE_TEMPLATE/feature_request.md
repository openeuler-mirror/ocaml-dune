---
name: Feature request
about: Suggest an idea to improve dune
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for filing an issue to help us improve Dune! -->
## Desired Behavior

<!-- Please describe the desired behavior in as much detail as you can. This
     should include the context in which you think this would be useful. -->

## Example

<!-- Please provide a concrete example of the proposed functionality. This would
     include a minimal working example of the files you're trying to build with.
     -->
