open! Dune_engine
open Stdune

let env = Memo.Run.Fdecl.create Env.to_dyn
