# Developer documentation

We use `doc/dev` for storing developer documentation, including specification,
design and implementation notes. Anything that should be user-facing should go
into the `doc` folder instead.
