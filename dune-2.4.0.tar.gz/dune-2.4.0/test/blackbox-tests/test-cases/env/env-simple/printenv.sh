#!/bin/bash

dune printenv $@
