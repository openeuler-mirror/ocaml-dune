int bla () {
    return 0;
}
