Foo.test ()
