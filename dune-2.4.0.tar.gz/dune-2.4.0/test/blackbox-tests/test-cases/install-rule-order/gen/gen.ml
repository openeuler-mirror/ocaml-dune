print_endline {ocaml|
let run () = print_endline "from gen.ml";;
|ocaml};;
