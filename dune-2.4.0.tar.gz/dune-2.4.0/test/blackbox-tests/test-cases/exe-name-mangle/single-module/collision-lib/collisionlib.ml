(* make sure everything is linked *)
let run = Exe.run
