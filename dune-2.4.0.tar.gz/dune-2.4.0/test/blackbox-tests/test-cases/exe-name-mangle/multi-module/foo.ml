(* finally calling into library *)
let run () = Bar.run ()
