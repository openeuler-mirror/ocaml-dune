let () =
  Foo.run ()
