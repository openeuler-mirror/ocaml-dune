#!/bin/sh

echo 'some contents'
