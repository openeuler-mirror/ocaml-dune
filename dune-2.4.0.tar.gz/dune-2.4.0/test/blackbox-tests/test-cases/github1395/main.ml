let () =
  Bar.f ()
