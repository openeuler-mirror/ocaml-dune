long f (void)
{
  return 1;
}
