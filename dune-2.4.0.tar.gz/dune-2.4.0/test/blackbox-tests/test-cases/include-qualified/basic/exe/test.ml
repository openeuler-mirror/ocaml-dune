let () =
  Foolib.Foo.Bar.run ();
  Foolib.Foo.A.B.run ()
