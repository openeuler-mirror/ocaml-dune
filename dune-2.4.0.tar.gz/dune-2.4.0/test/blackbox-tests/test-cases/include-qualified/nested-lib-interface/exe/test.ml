let () =
  Foolib.Bar.Fake.run ();
  Foolib.Bar.Baz.run ()
