#define ANSWER 42
