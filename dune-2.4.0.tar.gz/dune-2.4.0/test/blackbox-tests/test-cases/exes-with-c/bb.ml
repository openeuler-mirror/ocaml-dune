external foo : string -> unit = "foo"

let () =
  foo "B"
