print_string "foo/bar"
