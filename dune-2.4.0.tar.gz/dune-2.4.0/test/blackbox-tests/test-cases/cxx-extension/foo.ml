external foo : unit -> unit = "foo"
