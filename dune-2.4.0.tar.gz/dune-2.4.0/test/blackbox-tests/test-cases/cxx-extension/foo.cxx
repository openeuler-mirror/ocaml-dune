int cppfoo()
{
  return 42;
}
