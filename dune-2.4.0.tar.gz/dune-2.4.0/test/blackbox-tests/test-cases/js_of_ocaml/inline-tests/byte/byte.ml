let _ = assert (Sys.backend_type = Bytecode)
let _ = print_endline "inline tests (Byte)"
