let _ = assert (Sys.backend_type = Native)
let _ = print_endline "inline tests (Native)"
