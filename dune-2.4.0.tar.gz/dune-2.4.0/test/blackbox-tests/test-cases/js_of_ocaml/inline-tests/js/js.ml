let _ = assert (Sys.int_size = 32)
let _ = print_endline "inline tests (JS)"
