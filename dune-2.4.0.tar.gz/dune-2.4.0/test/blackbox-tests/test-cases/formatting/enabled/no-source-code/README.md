No format rules should be created for this directory, but no error should be
displayed (see #1479).
