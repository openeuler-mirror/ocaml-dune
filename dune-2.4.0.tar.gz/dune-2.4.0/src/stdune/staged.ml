type 'a t = 'a

let unstage t = t

let stage t = t
