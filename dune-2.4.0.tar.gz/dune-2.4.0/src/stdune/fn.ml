external id : 'a -> 'a = "%identity"

let const x _ = x
