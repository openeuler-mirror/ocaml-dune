let nolabel = Asttypes.Nolabel

let error_of_exn = Location.error_of_exn
