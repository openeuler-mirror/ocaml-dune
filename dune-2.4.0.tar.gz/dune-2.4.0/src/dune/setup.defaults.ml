let library_path = None

let library_destdir = None

let mandir = None
