let syntax =
  Dune_lang.Syntax.create ~name:"menhir" ~desc:"the menhir extension"
    [ (1, 1); (2, 1) ]
